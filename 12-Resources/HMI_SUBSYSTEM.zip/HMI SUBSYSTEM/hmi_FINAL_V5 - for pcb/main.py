# main.py -- HMI Subsystem 1 -- Team 308 -- Sam B
#
# Three states:
#   HUD     -- standby, nothing sent
#   MENU    -- tree navigation, nothing sent
#   CONTROL -- joystick bars on OLED, motor packets sent
#
# J1 double-click -- HUD<->MENU toggle, or CONTROL->HUD
# In MENU: J2 Y up/down, J2 X right=enter, J2 X left=back
#          J2 click = context action (depends on submenu)
# In CONTROL: J1=XY motors, J2=ZP future axes, clicks=button packets

from machine import UART, Pin
import time

import my_oled
import config
import startup
import input as inp
import msglog
import leds
import protocol
from menu import MenuEngine, MenuItem

# -- Hardware -----------------------------------------------------------------
uart = UART(config.UART_ID, baudrate=config.UART_BAUD,
            tx=config.UART_TX, rx=config.UART_RX)

def _make_adc(pin_num):
    if pin_num is None: return None
    try:
        from machine import ADC
        a = ADC(Pin(pin_num)); a.atten(ADC.ATTN_11DB); return a
    except Exception as e:
        print('[HW] ADC {} skipped: {}'.format(pin_num, e)); return None

j1_x   = _make_adc(config.J1_X_PIN)
j1_y   = _make_adc(config.J1_Y_PIN)
j2_x   = _make_adc(config.J2_X_PIN)
j2_y   = _make_adc(config.J2_Y_PIN)
btn_j1 = Pin(config.BTN_J1, Pin.IN, Pin.PULL_UP)
btn_j2 = Pin(config.BTN_J2, Pin.IN, Pin.PULL_UP)

# -- Boot ---------------------------------------------------------------------
boot   = startup.run(uart)
espnow = boot['espnow']
mqtt   = boot['mqtt']

msglog.add_sys('Boot W:{} M:{} E:{} U:{}'.format(
    'Y' if boot['wifi_ok']   else 'N',
    'Y' if boot['mqtt_ok']   else 'N',
    'Y' if boot['espnow_ok'] else 'N',
    'Y' if boot['uart_ok']   else 'N'))

# -- MQTT Heartbeat (every 5 minutes) ----------------------------------------
_HB_MS   = 5 * 60 * 1000
_last_hb = 0

def _mqtt_heartbeat():
    global _last_hb
    if not mqtt: return
    now = time.ticks_ms()
    if time.ticks_diff(now, _last_hb) < _HB_MS: return
    _last_hb = now
    try:
        import ujson
        pay = ujson.dumps({
            'sub'    : 1,
            'wifi'   : boot['wifi_ok'],
            'espnow' : boot['espnow_ok'],
            'status' : _status_code,
            'motors' : {str(k): list(v) for k,v in _motor_data.items()},
            'sensors': {'{}_{}'.format(k[0],k[1]): v
                        for k,v in _sensor_data.items()},
        })
        mqtt.publish(config.TOPIC_PUB, pay)
        print('[MQTT] Heartbeat sent')
        msglog.add_sys('MQTT HB sent')
        leds.evt_tx(0)
    except Exception as e:
        print('[MQTT] HB failed: {}'.format(e))

# -- Shared live state --------------------------------------------------------
_status_code = '--'
_motor_data  = {}   # {motor_id: (speed, dir)}  from Jacob Type 2
_sensor_data = {}   # {(sender,sensor_num): value}  from Type 3
_j1x = 0; _j1y = 0
_j2x = 0; _j2y = 0
_btn1_state = 0     # toggle state for J1 button press packet
_btn2_state = 0     # toggle state for J2 button press packet

# -- TX -----------------------------------------------------------------------

def _send(pkt, summary, type_int=0):
    """Send packet on all channels, log it, blink LED."""
    uart.write(pkt.encode())
    print('[TX] {}'.format(pkt))
    msglog.add_tx(summary)
    leds.evt_tx(type_int)
    if espnow:
        try: espnow.send(bytes(config.ADRIAN_MAC), pkt.encode())
        except Exception as e: print('[ESPNOW] TX err: {}'.format(e))
    if mqtt:
        try: mqtt.publish(config.TOPIC_PUB, pkt)
        except Exception as e: print('[MQTT] TX err: {}'.format(e))

# -- RX -----------------------------------------------------------------------
_rx_buf = ''

def _poll_rx():
    global _rx_buf

    if uart.any():
        raw = uart.read()
        if raw:
            try: _rx_buf += raw.decode('utf-8', 'ignore')
            except: pass

    if espnow:
        try:
            host, msg = espnow.recv(0)
            if msg:
                try: _rx_buf += msg.decode('utf-8', 'ignore')
                except: pass
                print('[ESPNOW] RX: {}'.format(msg))
        except Exception as e:
            print('[ESPNOW] RX err:', e)
                    
    if mqtt:
        try: mqtt.check_msg()
        except: pass

    while True:
        s = _rx_buf.find(protocol.PREFIX)
        if s == -1: _rx_buf = _rx_buf[-4:]; return
        e = _rx_buf.find(protocol.SUFFIX, s + 2)
        if e == -1: return
        pkt = _rx_buf[s : e + 2]
        _rx_buf = _rx_buf[e + 2:]
        _handle_rx(pkt)

def _handle_rx(pkt):
    global _status_code

    parsed = protocol.parse(pkt)

    if not parsed['valid']:
        print('[RX] invalid: {}'.format(parsed.get('reason', '')))
        msglog.add_err(parsed.get('reason', 'bad pkt'))
        leds.evt_bad_packet()
        return

    sender   = parsed['sender']
    receiver = parsed['receiver']
    t        = parsed['type_int']

    # Loopback
    if sender == protocol.MY_ID:
        print('[RX] loopback suppressed')
        return

    # Forward if not for us
    if receiver != protocol.MY_ID:
        uart.write(pkt.encode())
        print('[RX] fwd to {}: {}'.format(receiver, pkt))
        msglog.add('F', 'fwd>{}: {}'.format(receiver, parsed['summary']))
        leds.evt_rx_forward()
        return

    # For us
    print('[RX] T={} from={} {}'.format(t, sender, parsed['summary']))
    msglog.add_rx(parsed)

    if t in (2, 3, 10, 12, 13, 14, 15):
        leds.evt_rx_important(t)

    if t == 2:
        # Motor info from Jacob
        mid = parsed.get('motor_id', 0) #2 replaced MOTOR_ID
        _motor_data[mid] = (parsed.get('motor_spd', 0), parsed.get('motor_dir', 0))
        menu.mark_dirty()

    elif t == 3:
        if sender == '3':
            # Andrew's IMU: store yaw/pitch/roll individually
            _sensor_data[('3','1')] = parsed.get('imu_yaw',   '--')
            _sensor_data[('3','2')] = parsed.get('imu_pitch', 0)
            _sensor_data[('3','3')] = parsed.get('imu_roll',  0)
        else:
            # Other sensors: key by (sender, sensor_num)
            key = (sender, parsed.get('sensor_num', '?'))
            _sensor_data[key] = parsed.get('sensor_val', 0)
        print('[SENSOR] {}'.format(parsed.get('summary', '')))
        leds.evt_status_rx()
        menu.mark_dirty ()

    elif t == 10:
        # Error alert -- show full screen, auto-ACK
        ec = parsed.get('error_code', '?')
        ef = parsed.get('error_from', '?')
        leds.evt_error_alert(True)
        my_oled.clear()
        my_oled.title_bar('!! ERROR !!', invert=True)
        my_oled.text('Code: {}'.format(ec), 0, 18)
        my_oled.text('From: {}'.format(
            protocol.SUBSYS.get(ef, 'Sub'+str(ef))), 0, 30)
        my_oled.text('Sending ACK...', 0, 44)
        my_oled.show()
        time.sleep_ms(1500)
        ack = protocol.build_error_ack(ec if ec != '?' else 0)
        _send(ack, 'ERR ACK code={}'.format(ec), 14)
        leds.evt_error_alert(False)
        menu.mark_dirty()

    elif t in (12, 13, 15):
        # Status response / forwarded
        _status_code = str(parsed.get('status_code', '?'))
        leds.evt_status_rx()
        menu.mark_dirty()

# -- Motor TX (control mode only) ---------------------------------------------
_last_tx_ms = 0

def _send_motor(j1y): #j1x, j1y
    global _last_tx_ms
    now = time.ticks_ms()
    if time.ticks_diff(now, _last_tx_ms) < config.JOY_POLL_MS: return
    xs, xd = protocol.joy_to_speed_dir(j1x)
    ys, yd = protocol.joy_to_speed_dir(j1y)
    if xs > 0 or ys > 0:
        pkt_x, pkt_y = protocol.build_motor_speed(xs, xd, ys, yd)
        #_send(pkt_x, 'Mot1 {}:{}'.format(xs, 'R' if xd else 'F'), 1)
        _send(pkt_y, 'Mot2 {}:{}'.format(ys, 'R' if yd else 'L'), 1)
        time.sleep_ms(1000)
        _send(pkt_y, 'Mot2 {}:{}'.format(0, 'R' if 0 else 'L'), 1)
    _last_tx_ms = now

# -- Menu actions -------------------------------------------------------------

def _show_splash(title, *lines):
    my_oled.clear()
    my_oled.title_bar(title, invert=True)
    for i, l in enumerate(lines[:4]):
        my_oled.text(str(l)[:16], 0, 14 + i * 12)
    my_oled.show()
    time.sleep_ms(1400)
    menu.mark_dirty()

def act_status_req():
    pkt = protocol.build_status_request()
    _send(pkt, 'Status request', 12)

def act_ping_all():
    pkt = protocol.build_status_request()
    _send(pkt, 'Ping all subs', 12)

def act_request_sensors():
    # Request from each sensor subsystem via Adrian
    for sn in range(1, 4):
        pkt = protocol.build_sensor_request(sn)
        _send(pkt, 'Req sen#{}'.format(sn), 3)
        time.sleep_ms(50)

def act_retry_network():
    global boot, espnow, mqtt
    my_oled.splash('Retrying...', 'Network', 'Please wait')
    _, wifi_ok  = startup.connect_wifi()
    mqtt2, mqtt_ok = startup.connect_mqtt(wifi_ok)
    enow2, enow_ok = startup.init_espnow()
    boot['wifi_ok']    = wifi_ok
    boot['mqtt_ok']    = mqtt_ok
    boot['espnow_ok']  = enow_ok
    if mqtt2:  mqtt   = mqtt2
    if enow2:  espnow = enow2
    if wifi_ok: leds.evt_network_retry_ok()
    else:       leds.evt_network_retry_fail()
    msglog.add_sys('Net W:{} M:{} E:{}'.format(
        'Y' if wifi_ok else 'N',
        'Y' if mqtt_ok else 'N',
        'Y' if enow_ok else 'N'))
    menu.mark_dirty()

def act_msglog():
    global _log_screen_active
    _log_screen_active = True

def act_boot_status():
    _show_splash('Boot Status',
        'WiFi:   ' + ('OK' if boot['wifi_ok']   else 'FAIL'),
        'MQTT:   ' + ('OK' if boot['mqtt_ok']   else 'FAIL'),
        'ESPNOW: ' + ('OK' if boot['espnow_ok'] else 'FAIL'),
        'UART:   ' + ('OK' if boot['uart_ok']   else 'NO'))

def act_ping():
    pkt = protocol.build_ping()
    _send(pkt, 'Ping Adrian', 0)

def act_clear_log():
    msglog.clear()
    msglog.add_sys('Log cleared')

# -- Sensor value display helpers ---------------------------------------------

def _sen(sender, num, default='--'):
    return str(_sensor_data.get((sender, num), default))

def _light():
    # Mo sends sensor_num='6' (own sub ID); value 1=light, 0=no light
    v = _sensor_data.get(('6','6'), _sensor_data.get(('6','1'), None))
    if v is None: return '--'
    return 'ON' if v else 'OFF'

def _mot(mid):
    spd, d = _motor_data.get(mid, (0, 0))
    return '{:02d}/{}'.format(spd, 'R' if d else 'F')

# -- Menu tree ----------------------------------------------------------------
MENU_DEF = [
    MenuItem('> Control', kind='control'),

    MenuItem('Sensors', children=[
        # Light -- Mo (sub 6): sensor_num=6, value 0=no light 1=light
        MenuItem('Light',     value_fn=lambda: _light()),
        # Temp -- Sam M (sub 5) sensor 1
        MenuItem('Temp C',    value_fn=lambda: _sen('5','1')),
        # IMU -- Andrew (sub 3) sends yaw/pitch/roll
        MenuItem('IMU Yaw',   value_fn=lambda: _sen('3','1')),
        MenuItem('IMU Pitch', value_fn=lambda: _sen('3','2')),
        MenuItem('IMU Roll',  value_fn=lambda: _sen('3','3')),
    ]),

    MenuItem('Motors', children=[
        MenuItem('Motor 1',   value_fn=lambda: _mot(1)),
        MenuItem('Motor 2',   value_fn=lambda: _mot(2)),
        MenuItem('Motor 3',   value_fn=lambda: _mot(3)),
    ]),

    MenuItem('Status', children=[
        MenuItem('Req Status', action=act_status_req),
        MenuItem('Ping All',   action=act_ping_all),
        MenuItem('Last Code',  value_fn=lambda: _status_code),
    ]),

    MenuItem('Messages', children=[
        MenuItem('View Log',   action=act_msglog),
        MenuItem('Clear Log',  action=act_clear_log),
    ]),

    MenuItem('Network', children=[
        MenuItem('Boot Check', action=act_boot_status),
        MenuItem('Ping Adrian',action=act_ping),
        MenuItem('Retry All',  action=act_retry_network),
        MenuItem('WiFi',  value_fn=lambda: 'OK' if boot['wifi_ok']   else 'FAIL'),
        MenuItem('MQTT',  value_fn=lambda: 'OK' if boot['mqtt_ok']   else 'FAIL'),
        MenuItem('ESPNOW',value_fn=lambda: 'OK' if boot['espnow_ok'] else 'FAIL'),
    ]),

    MenuItem('Debug', children=[
        MenuItem('J1X raw', value_fn=lambda: str(j1_x.read()) if j1_x else 'N/A'),
        MenuItem('J1Y raw', value_fn=lambda: str(j1_y.read()) if j1_y else 'N/A'),
        MenuItem('J2X raw', value_fn=lambda: str(j2_x.read()) if j2_x else 'N/A'),
        MenuItem('J2Y raw', value_fn=lambda: str(j2_y.read()) if j2_y else 'N/A'),
        MenuItem('J1 scl',  value_fn=lambda: '{:+d}/{:+d}'.format(_j1x,_j1y)),
        MenuItem('J2 scl',  value_fn=lambda: '{:+d}/{:+d}'.format(_j2x,_j2y)),
        MenuItem('State',   value_fn=lambda: menu.state),
        MenuItem('RX buf',  value_fn=lambda: str(len(_rx_buf))),
    ]),
]

menu = MenuEngine(root_items=MENU_DEF, title='HMI MENU')

# -- Log screen ---------------------------------------------------------------
_log_screen_active = False

# -- ADC calibration print ----------------------------------------------------
def _cal():
    print('[CAL] Centers -- do not touch sticks')
    time.sleep_ms(100)
    for name, adc in [('J1X',j1_x),('J1Y',j1_y),('J2X',j2_x),('J2Y',j2_y)]:
        if adc:
            avg = sum(adc.read() for _ in range(20)) // 20
            print('[CAL] {} raw={} (center={} diff={:+d})'.format(
                name, avg, config.JOY_CENTER, avg - config.JOY_CENTER))
        else:
            print('[CAL] {} = no pin'.format(name))

_cal()
print('[MAIN] Ready -- J1 double-click = menu')

# -- Main loop ----------------------------------------------------------------
while True:

    # 1. Read all inputs
    j1x, j1y, j2x, j2y, j1x_ev, j1y_ev, j2x_ev, j2y_ev = inp.read_all(
        j1_x, j1_y, j2_x, j2_y, btn_j1, btn_j2)
    _j1x = j1x; _j1y = j1y; _j2x = j2x; _j2y = j2y

    # 2. J1 double-click -- universal state toggle
    if inp.btn1.double_click:
        _log_screen_active = False
        if menu.is_hud():    menu.go_menu()
        else:                menu.go_hud()

    # 3. J1 single click -- button packet in control mode
    if inp.btn1.single_click and menu.is_control():
        _btn1_state = 1 - _btn1_state
        pkt = protocol.build_button_press(1, _btn1_state)
        _send(pkt, 'Btn1={}'.format(_btn1_state), 67)

    # 4. J2 single click -- button packet in control, context action in menu
    if inp.btn2.single_click:
        if menu.is_control():
            _btn2_state = 1 - _btn2_state
            pkt = protocol.build_button_press(2, _btn2_state)
            _send(pkt, 'Btn2={}'.format(_btn2_state), 67)
        elif menu.is_menu():
            ctx = menu.current_parent()
            if   ctx == 'Network': act_retry_network()
            elif ctx == 'Status':  act_status_req()
            elif ctx == 'Sensors': act_request_sensors()
            else:                  menu.enter()

    # 5. State logic
    if _log_screen_active:
        if j2y_ev == -1: msglog.scroll(-1); menu.mark_dirty()
        elif j2y_ev == 1: msglog.scroll(1); menu.mark_dirty()
        if inp.btn1.single_click or inp.btn2.long_press:
            _log_screen_active = False
            menu.mark_dirty()
        menu.draw_msglog()

    elif menu.is_control():
        _send_motor(j1y) #j1x, j1y
        menu.mark_dirty()
        menu.draw(j1y, j2x, j2y) #(j1x, j1y, j2x, j2y)

    elif menu.is_menu():
        safe_y = j2y_ev if abs(j2y) > config.JOY_MENU_THRESH else 0
        safe_x = j2x_ev if abs(j2x) > config.JOY_MENU_THRESH else 0
        if safe_y == -1:   menu.move(-1)
        elif safe_y == 1:  menu.move(1)
        if safe_x == 1:    menu.enter()
        elif safe_x == -1: menu.back()
        if inp.btn2.long_press: menu.back()
        if menu.is_control(): msglog.add_sys('Control mode ON')
        menu.draw(j1x, j1y, j2x, j2y)

    else:
        menu.draw(j1x, j1y, j2x, j2y)

    # 6. RX always
    _poll_rx()

    # 7. MQTT heartbeat
    _mqtt_heartbeat()

    # 8. LED poll
    leds.poll()

    time.sleep_ms(10)

