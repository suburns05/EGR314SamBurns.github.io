# protocol.py -- HMI ASCII Protocol -- Team 308
#
# Frame:  AZ + sender + receiver + msg_type + data + YB
# All fields are single ASCII characters.
# Types above 9 use hex char: type 10='A', 12='C', 13='D', 14='E', 15='F'
# This matches Jacob's dummy test code format exactly.
#
# Jacob's example: '415A241414415942'
#   41 5A = AZ header
#   2      = sender (Adrian)
#   4      = receiver (Jacob)
#   1      = type 1 (motor set)
#   4 14 41= data
#   59 42  = YB footer
#
# Type reference (hex char encoding):
#   Type  1 = '1'   Motor speed set
#   Type  2 = '2'   Motor info display
#   Type  3 = '3'   Sensor value
#   Type 10 = 'A'   Error alert (0x0A)
#   Type 12 = 'C'   Status request/response (0x0C)
#   Type 13 = 'D'   Status forwarded (0x0D)
#   Type 14 = 'E'   Error ACK (0x0E)
#   Type 15 = 'F'   Status response (0x0F)
#   Type 20 = 'K'   Hub command (0x14... actually chr(20))
#   Type 67 = 'C'   Button press (0x43) -- NOTE: conflicts with Type 12
#                   Resolved: button uses full string '43'

PREFIX   = 'AZ'
SUFFIX   = 'YB'
MY_ID    = '1'
ADRIAN   = '2'
JACOB    = '4'

# Type char constants -- use these everywhere, never hardcode
T_MOTOR_SET    = '1'   # type 1
T_MOTOR_INFO   = '2'   # type 2
T_SENSOR       = '3'   # type 3
T_ERROR_ALERT  = 'A'   # type 10
T_STATUS       = 'C'   # type 12
T_STATUS_FWD   = 'D'   # type 13
T_ERROR_ACK    = 'E'   # type 14
T_STATUS_RESP  = 'F'   # type 15
T_BUTTON       = '43'  # type 67 -- two chars to avoid collision with T_STATUS

# Subsystem names
SUBSYS = {'1':'Sam B','2':'Adrian','3':'Andrew','4':'Jacob','5':'Sam M','6':'Mo'}

# Sensor number assignments (confirmed from team datasheets)
# Mo   (sub 6): sensor_num=1, type 3 -- Light (photoresistor)
# Sam M(sub 5): sensor_num=1, type 3 -- Temperature (Celsius)
# Andrew(sub 3): type 3 -- IMU yaw/pitch/roll (upper+lower byte pairs)
SENSOR_NAMES = {
    ('6','1'): 'Light',
    ('6','6'): 'Light',   # Mo sends sensor_num=6 (own sub ID)
    ('5','1'): 'Temp C',
    ('3','1'): 'IMU Yaw',
    ('3','2'): 'IMU Pitch',
    ('3','3'): 'IMU Roll',
}

def _clamp(v, lo, hi):
    return max(lo, min(hi, int(v)))

# -- Outbound builders --------------------------------------------------------

def build_motor_speed(xs, xd, ys, yd):
    """
    Type 1 -- Motor speed set.
    xs: x_speed 0-15  xd: x_dir 0=fwd 1=rev
    ys: y_speed 0-15  yd: y_dir 0=left 1=right
    Packet: AZ12 1 xs xd ys yd 0 YB
    Jacob's format: motor_id in byte3, upper+lower speed in 4+5
    We send X axis as motor 1, Y axis as motor 2 in separate packets.
    """
    xs = _clamp(xs, 0, 15)
    ys = _clamp(ys, 0, 15)
    xd = 1 if xd else 0
    yd = 1 if yd else 0
    # Motor 1 = X axis, Motor 2 = Y axis (matches Jacob's motor_id field)
    pkt_x = PREFIX + MY_ID + JACOB + T_MOTOR_SET + '1' + str(xs) + str(xd) + SUFFIX
    pkt_y = PREFIX + MY_ID + JACOB + T_MOTOR_SET + '2' + str(ys) + str(yd) + SUFFIX
    return pkt_x, pkt_y

def build_status_request():
    """Type 12 -- Request system status from Adrian."""
    return PREFIX + MY_ID + ADRIAN + T_STATUS + SUFFIX

def build_error_ack(error_code):
    """Type 14 -- Acknowledge error received from Adrian."""
    ec = _clamp(error_code, 0, 64)
    return PREFIX + MY_ID + ADRIAN + T_ERROR_ACK + str(ec) + SUFFIX

def build_button_press(button_num, button_state):
    """
    Type 67 -- Button click-in event.
    button_num: 1=J1, 2=J2
    button_state: 0=off, 1=on
    Uses '43' as type string to avoid collision with Type 12 'C'.
    """
    bn = _clamp(button_num, 1, 2)
    bs = 1 if button_state else 0
    return PREFIX + MY_ID + ADRIAN + T_BUTTON + str(bn) + str(bs) + SUFFIX

def build_sensor_request(sensor_num):
    """Type 3 outbound -- Request a sensor reading."""
    sn = _clamp(sensor_num, 1, 5)
    return PREFIX + MY_ID + ADRIAN + T_SENSOR + str(sn) + SUFFIX

def build_ping():
    """Boot ping -- check if Adrian is on the bus."""
    return PREFIX + MY_ID + ADRIAN + 'P' + SUFFIX

# -- Joy to speed conversion --------------------------------------------------

def joy_to_speed_dir(signed_val):
    """
    Convert signed -127..+127 joystick to (speed 0-15, direction).
    Dead zone: abs(val) <= 8 = stopped.
    """
    if abs(signed_val) <= 8:
        return 0, 0
    speed = _clamp(int(abs(signed_val) / 127 * 15), 0, 15)
    direction = 0 if signed_val >= 0 else 1
    return speed, direction

# -- Inbound parser -----------------------------------------------------------

def _type_int(char):
    """Convert type char to int. Handles hex chars A-F."""
    try:
        return int(char, 16)
    except:
        return ord(char)

def parse(pkt):
    """
    Parse a raw ASCII packet string.
    Returns dict with:
      valid, sender, receiver, type_char, type_int, data, summary
      + type-specific fields
    """
    if not (pkt.startswith(PREFIX) and pkt.endswith(SUFFIX)):
        return {'valid': False, 'reason': 'bad frame'}

    payload = pkt[len(PREFIX):-len(SUFFIX)]
    if len(payload) < 3:
        return {'valid': False, 'reason': 'too short'}

    sender    = payload[0]
    receiver  = payload[1]
    type_char = payload[2]
    data      = payload[3:]
    t         = _type_int(type_char)

    r = {
        'valid'    : True,
        'sender'   : sender,
        'receiver' : receiver,
        'type_char': type_char,
        'type_int' : t,
        'data'     : data,
        'summary'  : 'T{} from {}'.format(t, SUBSYS.get(sender, 'Sub'+sender)),
    }

    try:
        if t == 2 and len(data) >= 3:
            # Type 2 -- Motor info from Jacob
            # Jacob format: motor_id + upper_speed + lower_speed + direction
            motor_id  = int(data[0])
            spd_upper = int(data[1]) 
            spd_lower = int(data[2]) if len(data) > 2 else 0
            motor_spd = (spd_upper << 4) | spd_lower  # or just use upper
            motor_dir = int(data[3]) if len(data) > 3 else 0
            r.update({
                'motor_id' : motor_id,
                'motor_spd': spd_upper,  # 10-15
                'motor_dir': motor_dir,
                'summary'  : 'Mot#{} spd={:02d} {}'.format(
                    motor_id, spd_upper, 'REV' if motor_dir else 'FWD'),
            })

        elif t == 3 and len(data) >= 1:
            # Type 3 -- Sensor value
            # Andrew (IMU sub 3): "yaw,pitch,roll" ASCII string
            #   e.g. data = "NE,4,-30"  yaw=compass, pitch/roll=-180..180
            # Mo (Light sub 6): sensor_num + upper + lower
            # Sam M (Temp sub 5): sensor_num + upper + lower
            if sender == '3':
                # Andrew's IMU format: yaw,pitch,roll
                parts = data.split(',')
                yaw   = parts[0] if len(parts) > 0 else '?'
                try:    pitch = int(parts[1]) if len(parts) > 1 else 0
                except: pitch = 0
                try:    roll  = int(parts[2]) if len(parts) > 2 else 0
                except: roll  = 0
                r.update({
                    'imu_yaw'  : yaw,
                    'imu_pitch': pitch,
                    'imu_roll' : roll,
                    'sensor_num': '1',
                    'sensor_val': 0,
                    'sensor_name': 'IMU',
                    'summary'  : 'Yaw={} Pit={} Rol={}'.format(yaw, pitch, roll),
                })
            else:
                sensor_num = data[0]
                upper      = int(data[1]) if len(data) > 1 else 0
                lower      = int(data[2:]) if len(data) > 2 else 0
                value      = (upper << 8) | lower
                name       = SENSOR_NAMES.get((sender, sensor_num),
                             'Sen{}:{}'.format(sender, sensor_num))
                r.update({
                    'sensor_num': sensor_num,
                    'sensor_val': value,
                    'sensor_name': name,
                    'summary'   : '{} = {}'.format(name, value),
                })

        elif t == 10 and len(data) >= 2:
            # Type 10 -- Error alert
            error_code = data[0]
            sender_num = data[1] if len(data) > 1 else '?'
            r.update({
                'error_code': error_code,
                'error_from': sender_num,
                'summary'   : 'ERR {} from {}'.format(
                    error_code, SUBSYS.get(sender_num, 'Sub'+sender_num)),
            })

        elif t == 12 and len(data) >= 1:
            # Type 12 -- Status response
            code = data[0]
            r.update({
                'status_code': code,
                'summary'    : 'Status={}'.format(code),
            })

        elif t == 13 and len(data) >= 2:
            # Type 13 -- Status forwarded
            sender_num  = data[0]
            status_code = data[1]
            r.update({
                'status_from': sender_num,
                'status_code': status_code,
                'summary'    : 'Sts {} code={}'.format(
                    SUBSYS.get(sender_num, 'Sub'+sender_num), status_code),
            })

        elif t == 14 and len(data) >= 2:
            # Type 14 -- Error ACK from another sub
            error_code = data[0]
            sender_num = data[1]
            r.update({
                'error_code': error_code,
                'ack_from'  : sender_num,
                'summary'   : 'ERR ACK {} from {}'.format(
                    error_code, SUBSYS.get(sender_num, 'Sub'+sender_num)),
            })

        elif t == 15 and len(data) >= 2:
            # Type 15 -- Subsystem status response
            sender_num  = data[0]
            status_code = data[1]
            r.update({
                'status_from': sender_num,
                'status_code': status_code,
                'summary'    : 'StsRsp {} ok={}'.format(
                    SUBSYS.get(sender_num, 'Sub'+sender_num), status_code),
            })

    except Exception as e:
        r['summary'] = r['summary'] + ' (parse err)'
        print('[PROTO] parse error: {}'.format(e))

    return r


