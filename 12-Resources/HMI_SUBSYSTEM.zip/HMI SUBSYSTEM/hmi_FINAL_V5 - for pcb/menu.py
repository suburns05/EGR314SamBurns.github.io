
import my_oled
import time

STATE_HUD     = 'hud'
STATE_MENU    = 'menu'
STATE_CONTROL = 'control'

ROW_H        = 11
MENU_Y_START = 12
VISIBLE_ROWS = 4

class MenuItem:
    def __init__(self, label, children=None, action=None,
                 value_fn=None, kind='normal'):
        
        self.label    = label
        self.children = children or []
        self.action   = action
        self.value_fn = value_fn
        self.kind     = 'submenu' if children else kind

    @property
    def has_children(self):
        return bool(self.children)

class MenuEngine:
    def __init__(self, root_items, title='MENU'):
        self.root       = root_items
        self.base_title = title
        self.state      = STATE_HUD

        self._items  = root_items
        self._cursor = 0
        self._scroll = 0
        self._stack  = []   # list of (items, cursor, scroll)

        self._dirty  = True

    def is_hud(self):     return self.state == STATE_HUD
    def is_menu(self):    return self.state == STATE_MENU
    def is_control(self): return self.state == STATE_CONTROL

    def go_hud(self):
        print('[MENU] → HUD')
        self.state   = STATE_HUD
        self._stack  = []
        self._items  = self.root
        self._cursor = 0
        self._scroll = 0
        self._dirty  = True

    def go_menu(self):
        print('[MENU] → MENU')
        self.state  = STATE_MENU
        self._dirty = True

    def go_control(self):
        print('[MENU] → CONTROL')
        self.state  = STATE_CONTROL
        self._dirty = True

    def move(self, delta):
        n = len(self._items)
        if not n: return
        self._cursor = (self._cursor + delta) % n
        if self._cursor < self._scroll:
            self._scroll = self._cursor
        elif self._cursor >= self._scroll + VISIBLE_ROWS:
            self._scroll = self._cursor - VISIBLE_ROWS + 1
        self._dirty = True

    def enter(self):
        if not self._items: return
        item = self._items[self._cursor]
        if item.has_children:
            self._stack.append((self._items, self._cursor, self._scroll))
            self._items  = item.children
            self._cursor = 0
            self._scroll = 0
            self._dirty  = True
        elif item.kind == 'control':
            self.go_control()
        elif item.action:
            item.action()
            self._dirty = True

    def back(self):
        if self._stack:
            self._items, self._cursor, self._scroll = self._stack.pop()
            self._dirty = True
        else:
            self.go_hud()

    def draw(self, j1x=0, j1y=0, j2x=0, j2y=0):
        
        if not self._dirty:
            return
        self._dirty = False

        if self.state == STATE_HUD:
            self._draw_hud()
        elif self.state == STATE_MENU:
            self._draw_menu()
        elif self.state == STATE_CONTROL:
            self._draw_control(j1x, j1y, j2x, j2y)

    def mark_dirty(self):
        
        self._dirty = True

    def current_parent(self):
        
        if not self._stack:
            return ''
        items, cursor, _ = self._stack[-1]
        return items[cursor].label

    def _draw_hud(self):
        my_oled.clear()
        my_oled.title_bar('HMI  SUB1', invert=True)
        my_oled.center_text('Standby', 28)
        my_oled.center_text('J1 dbl = menu', 42)
        my_oled.status_bar('TEAM308', 'OK')
        my_oled.show()

    def _draw_menu(self):
        my_oled.clear()
        my_oled.title_bar(self._current_title(), invert=True)

        visible_end = min(self._scroll + VISIBLE_ROWS, len(self._items))
        for i, idx in enumerate(range(self._scroll, visible_end)):
            item     = self._items[idx]
            y        = MENU_Y_START + i * ROW_H
            selected = (idx == self._cursor)

            if selected:
                my_oled.fill_rect(0, y, my_oled.OLED_W - 4, ROW_H, 1)

            arrow = '+' if item.has_children else \
                    '>' if item.kind == 'control' else ' '
            col = 0 if selected else 1
            my_oled.text(arrow + item.label[:13], 2, y + 1, col)

            if item.value_fn:
                val = str(item.value_fn())[-5:]
                my_oled.text(val, my_oled.OLED_W - len(val)*8 - 4, y+1, col)

        my_oled.draw_scrollbar(self._cursor, len(self._items))
        left  = '{}/{}'.format(self._cursor+1, len(self._items))
        right = 'BCK' if self._stack else 'EXIT'
        my_oled.status_bar(left, right)
        my_oled.show()

    def _current_title(self):
        if not self._stack:
            return self.base_title
        labels = [self._stack[i][0][self._stack[i][1]].label
                  for i in range(len(self._stack))]
        return ('>' if len(labels)==1 else '..>') + labels[-1]

    def _draw_control(self, j1x, j1y, j2x, j2y):
        my_oled.clear()
        my_oled.title_bar('CONTROL MODE', invert=True)
        self._draw_joy_bars(0,  13, 'J1', j1x, j1y)
        self._draw_joy_bars(66, 13, 'J2', j2x, j2y)
        my_oled.vline(63, 12, 40, 1)
        my_oled.hline(0, 52, my_oled.OLED_W, 1)
        my_oled.text('{:+4d}/{:+4d}'.format(j1x, j1y), 0,  55)
        my_oled.text('{:+4d}/{:+4d}'.format(j2x, j2y), 66, 55)
        my_oled.show()

    def draw_msglog(self):
        import msglog
        msglog.draw()

    def _draw_joy_bars(self, x_off, y_off, label, jx, jy):
        
        bar_w = 56    # total bar width
        bar_h = 6

        my_oled.text(label, x_off, y_off)

        my_oled.text('X', x_off,     y_off + 10)
        my_oled.rect(x_off + 8, y_off + 10, bar_w, bar_h, 1)
        cx = x_off + 8 + bar_w // 2
        fill = int(abs(jx) / 127 * (bar_w // 2))
        if jx >= 0:
            my_oled.fill_rect(cx,          y_off+10, fill, bar_h, 1)
        else:
            my_oled.fill_rect(cx - fill,   y_off+10, fill, bar_h, 1)

        my_oled.text('Y', x_off,     y_off + 22)
        my_oled.rect(x_off + 8, y_off + 22, bar_w, bar_h, 1)
        fill = int(abs(jy) / 127 * (bar_w // 2))
        if jy >= 0:
            my_oled.fill_rect(cx,          y_off+22, fill, bar_h, 1)
        else:
            my_oled.fill_rect(cx - fill,   y_off+22, fill, bar_h, 1)
