
import time
import config

def adc_to_signed(raw):
    
    if raw >= 2200:
        return int((raw - 2200) / (4095 - 2200) * 127)
    elif raw <= 1800:
        if raw == 0: return -127
        return -int((1800 - raw) / 1800 * 127)
    return 0   # dead zone 1800-2200

class InputState:
    
    def __init__(self):
        self.j1_x = 0     # signed -127..+127
        self.j1_y = 0
        self.j2_x = 0
        self.j2_y = 0
        self.btn_j1 = 1   # raw pin (1=released, 0=pressed, pull-up)
        self.btn_j2 = 1

state = InputState()

class ButtonHandler:
    
    def __init__(self, dbl_ms=None, long_ms=None):
        self.dbl_ms   = dbl_ms  or config.DBL_CLICK_MS
        self.long_ms  = long_ms or config.LONG_PRESS_MS
        self._prev        = 1
        self._press_time  = 0
        self._last_click  = 0
        self._fired       = False
        self.single_click = False
        self.double_click = False
        self.long_press   = False

    def update(self, val):
        now = time.ticks_ms()
        self.single_click = False
        self.double_click = False
        self.long_press   = False

        edge_down = (self._prev == 1 and val == 0)
        edge_up   = (self._prev == 0 and val == 1)

        if edge_down:
            self._press_time = now
            self._fired = False

        if val == 0 and not self._fired:
            if time.ticks_diff(now, self._press_time) >= self.long_ms:
                self._fired = True
                self.long_press = True

        if edge_up and not self._fired:
            gap = time.ticks_diff(now, self._last_click)
            if gap < self.dbl_ms:
                self.double_click = True
            else:
                self.single_click = True
            self._last_click = now

        self._prev = val

class JoyEdge:
    
    def __init__(self, thresh=None, repeat_ms=None):
        self.thresh     = thresh    or config.JOY_MENU_THRESH
        self.repeat_ms  = repeat_ms or config.JOY_MENU_RPT_MS
        self._last_fire = 0
        self._direction = 0   # -1, 0, +1

    def update(self, signed_val):
        
        now = time.ticks_ms()
        if signed_val >  self.thresh:  new_dir =  1
        elif signed_val < -self.thresh: new_dir = -1
        else:                           new_dir =  0

        if new_dir == 0:
            self._direction = 0
            self._last_fire = 0
            return 0

        if new_dir != self._direction:
            self._direction = new_dir
            self._last_fire = now
            return new_dir

        if time.ticks_diff(now, self._last_fire) >= self.repeat_ms:
            self._last_fire = now
            return new_dir

        return 0

btn1 = ButtonHandler()
btn2 = ButtonHandler()

j1_x_edge = JoyEdge()
j1_y_edge = JoyEdge()
j2_x_edge = JoyEdge()
j2_y_edge = JoyEdge()

def read_all(j1_x_adc, j1_y_adc, j2_x_adc, j2_y_adc,
             btn_j1_pin, btn_j2_pin):
    
    def _avg(adc, n=8):
        if adc is None: return 0
        return adc_to_signed(sum(adc.read() for _ in range(n)) // n)

    j1x = _avg(j1_x_adc)
    j1y = _avg(j1_y_adc)
    j2x = _avg(j2_x_adc)
    j2y = _avg(j2_y_adc)

    state.j1_x = j1x
    state.j1_y = j1y
    state.j2_x = j2x
    state.j2_y = j2y

    btn1.update(btn_j1_pin.value())
    btn2.update(btn_j2_pin.value())

    if btn1.double_click:
        print('[INPUT] J1 double-click')

    if btn1.single_click:
        print('[INPUT] J1 click')

    if btn1.long_press:
        print('[INPUT] J1 long press')

    if btn2.single_click:
        print('[INPUT] J2 click')

    if btn2.double_click:
        print('[INPUT] J2 double-click')

    if btn2.long_press:
        print('[INPUT] J2 long press')

    j1x_ev = j1_x_edge.update(j1x)
    j1y_ev = j1_y_edge.update(j1y)
    j2x_ev = j2_x_edge.update(j2x)
    j2y_ev = j2_y_edge.update(j2y)

    if j1x_ev: print('[INPUT] J1_X {:+4d} dir={:+d}'.format(j1x, j1x_ev))
    if j1y_ev: print('[INPUT] J1_Y {:+4d} dir={:+d}'.format(j1y, j1y_ev))
    if j2x_ev: print('[INPUT] J2_X {:+4d} dir={:+d}'.format(j2x, j2x_ev))
    if j2y_ev: print('[INPUT] J2_Y {:+4d} dir={:+d}'.format(j2y, j2y_ev))

    return j1x, j1y, j2x, j2y, j1x_ev, j1y_ev, j2x_ev, j2y_ev
