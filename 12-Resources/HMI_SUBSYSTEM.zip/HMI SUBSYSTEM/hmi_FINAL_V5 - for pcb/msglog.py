
import my_oled

MAX_MSGS  = 10
ROW_H     = 10
LOG_Y     = 12     # below title bar
VISIBLE   = 5      # rows visible at once (64-12-10=42 → 4.2 → 4, use 5 tight)

TAG_RX   = '<'    # received
TAG_TX   = '>'    # sent
TAG_FWD  = 'F'    # forwarded
TAG_ERR  = '!'    # error
TAG_SYS  = '*'    # system event

_log  = []        # list of (tag, summary_str)
_scroll = 0       # index of topmost visible entry

def add(tag, summary):
    
    global _scroll
    _log.append((tag, str(summary)[:22]))
    if len(_log) > MAX_MSGS:
        _log.pop(0)
    _scroll = max(0, len(_log) - VISIBLE)
    print('[LOG] {} {}'.format(tag, summary))

def add_rx(parsed):
    
    add(TAG_RX, parsed.get('summary', 'unknown'))

def add_tx(summary):
    add(TAG_TX, summary)

def add_err(reason):
    add(TAG_ERR, reason)

def add_sys(msg):
    add(TAG_SYS, msg)

def scroll(delta):
    
    global _scroll
    max_scroll = max(0, len(_log) - VISIBLE)
    _scroll = max(0, min(max_scroll, _scroll + delta))

def clear():
    global _scroll
    _log.clear()
    _scroll = 0

def draw():
    
    my_oled.clear()
    my_oled.title_bar('MSG LOG', invert=True)

    if not _log:
        my_oled.center_text('No messages', 30)
        my_oled.show()
        return

    visible_end = min(_scroll + VISIBLE, len(_log))
    for i, idx in enumerate(range(_scroll, visible_end)):
        tag, summary = _log[idx]
        y = LOG_Y + i * ROW_H
        my_oled.text(tag, 0, y, 1)
        my_oled.text(summary[:18], 8, y, 1)

    my_oled.draw_scrollbar(
        min(_scroll, max(0, len(_log)-1)),
        max(1, len(_log)),
        x=124, y_start=LOG_Y,
        height=my_oled.OLED_H - LOG_Y - 10)

    total = len(_log)
    shown_end = min(_scroll + VISIBLE, total)
    my_oled.status_bar('{}-{}/{}'.format(_scroll+1, shown_end, total), 'J2=scroll')
    my_oled.show()
