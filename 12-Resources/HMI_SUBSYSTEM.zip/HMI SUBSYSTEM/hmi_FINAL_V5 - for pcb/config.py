# config.py -- HMI Subsystem 1 -- Team 308 -- Sam B

# ============================================================
# NETWORK TOGGLES -- set True/False to enable/disable
# ============================================================
WIFI_ENABLE   = False   # set True to connect to WiFi
MQTT_ENABLE   = False   # set True to use MQTT (requires WIFI_ENABLE)
ESPNOW_ENABLE = True   # set True to use ESP-NOW with Adrian
# ============================================================

# -- MQTT / WiFi --------------------------------------------------------------
TEAM          = 'EGR314/Team308/SEUB'
TOPIC_PUB     = TEAM + '/PUB'
TOPIC_SUB     = TEAM + '/SUB'
MQTT_SERVER   = '34.210.232.255'
MQTT_USER     = 'student'
MQTT_PASSWORD = 'egr3x4'
WIFI_SSID     = 'photon'
WIFI_PASSWORD = 'particle'
WIFI_TIMEOUT_MS = 10000

# -- ESP-NOW ------------------------------------------------------------------
ADRIAN_MAC    = [0xD4, 0x8C, 0x49, 0xE4, 0xD9, 0xC0]


# -- UART ---------------------------------------------------------------------
UART_ID   = 2
UART_TX   = 37
UART_RX   = 36
UART_BAUD = 9600

# -- Joystick 1 (LEFT) -- motor commands + menu toggle ------------------------
J1_X_PIN  = None   # ADC1 ch6 -- WiFi-safe
J1_Y_PIN  = 6 #None   # ADC1 ch7 -- WiFi-safe
BTN_J1    = 14    # double-click = toggle menu | single in control = btn packet

# -- Joystick 2 (RIGHT) -- menu navigation only -------------------------------
J2_X_PIN  = 4   # ADC1 ch4 -- WiFi-safe
J2_Y_PIN  = 5   # ADC1 ch5 -- WiFi-safe
BTN_J2    = 13  # context action in menu | single in control = btn packet

# -- Joystick tuning ----------------------------------------------------------
JOY_CENTER      = 1800   # raw ADC at rest (confirmed by joy_test.py)
JOY_DEAD_ZONE   = 400   # raw counts either side of center = zero
JOY_MAX_OUT     = 127    # scaled output range -127..+127
JOY_MENU_THRESH = 90     # scaled units to register a menu move
JOY_POLL_MS     = 880     # motor packet interval ms
JOY_MENU_RPT_MS = 350    # menu auto-repeat while held

# -- Button timing ------------------------------------------------------------
DBL_CLICK_MS  = 450
LONG_PRESS_MS = 1000

# -- OLED ---------------------------------------------------------------------
OLED_SCL  = 18
OLED_SDA  = 17
OLED_ADDR = 0x3C

# -- LEDs (active HIGH) -------------------------------------------------------
LED_WIFI_PIN = 35   # Activity / connection
LED_BLUE_PIN = 36  # Alert / error


