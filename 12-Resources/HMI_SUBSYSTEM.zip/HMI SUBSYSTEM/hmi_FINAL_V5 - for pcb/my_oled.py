# my_oled.py — HMI OLED Driver
# SSD1306 128x64 via SoftI2C (SCL=18, SDA=19)

from machine import Pin, SoftI2C
import ssd1306

# ─── Display init ─────────────────────────────────────────────────────────────
i2c          = SoftI2C(scl=Pin(18), sda=Pin(17))
OLED_W       = 128
OLED_H       = 64
oled         = ssd1306.SSD1306_I2C(OLED_W, OLED_H, i2c)

# ─── Low-level helpers ────────────────────────────────────────────────────────

def clear():
    oled.fill(0)

def show():
    oled.show()

def clear_show():
    oled.fill(0)
    oled.show()

def text(s, x, y, color=1):
    oled.text(s, x, y, color)

def hline(x, y, w, color=1):
    oled.hline(x, y, w, color)

def vline(x, y, h, color=1):
    oled.vline(x, y, h, color)

def rect(x, y, w, h, color=1):
    oled.rect(x, y, w, h, color)

def fill_rect(x, y, w, h, color=1):
    oled.fill_rect(x, y, w, h, color)

def pixel(x, y, color=1):
    oled.pixel(x, y, color)

# ─── Mid-level helpers ────────────────────────────────────────────────────────

def title_bar(label, invert=True):
    """Draw a solid title bar at the top (y=0..9)."""
    if invert:
        fill_rect(0, 0, OLED_W, 10, 1)
        text(label[:15], 1, 1, 0)
    else:
        text(label[:15], 1, 1, 1)
    hline(0, 10, OLED_W, 1)

def status_bar(left='', right=''):
    """Draw a status bar at the bottom (y=55..63)."""
    hline(0, 54, OLED_W, 1)
    text(left[:8],  1,  56, 1)
    if right:
        text(right[-8:], OLED_W - len(right[-8:]) * 8, 56, 1)

def draw_scrollbar(selected, total, x=124, y_start=12, height=40):
    """Thin scrollbar on the right edge."""
    if total <= 1:
        return
    vline(x, y_start, height, 1)
    thumb_h = max(4, height // total)
    thumb_y = y_start + int((height - thumb_h) * selected / max(1, total - 1))
    fill_rect(x, thumb_y, 3, thumb_h, 1)

def splash(line1, line2='', line3=''):
    """Full-screen splash / boot screen."""
    clear()
    text(line1[:16], max(0, (16 - len(line1)) * 4), 16, 1)
    if line2:
        text(line2[:16], max(0, (16 - len(line2)) * 4), 28, 1)
    if line3:
        text(line3[:16], max(0, (16 - len(line3)) * 4), 40, 1)
    show()

def draw_checkbox(x, y, checked):
    rect(x, y, 7, 7, 1)
    if checked:
        text('X', x + 1, y, 1)

def center_text(s, y, color=1):
    x = max(0, (OLED_W - len(s) * 8) // 2)
    text(s, x, y, color)

def invert_row(y, h=10):
    """Invert a horizontal band — used for selection highlight."""
    for row in range(y, min(y + h, OLED_H)):
        for col in range(OLED_W):
            oled.pixel(col, row, 1 - oled.pixel(col, row))
