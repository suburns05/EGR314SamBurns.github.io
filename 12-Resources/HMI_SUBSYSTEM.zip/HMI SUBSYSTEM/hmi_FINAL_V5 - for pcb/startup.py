# startup.py -- HMI Boot Sequence
# All network features gated by config flags.
# Set WIFI_ENABLE, MQTT_ENABLE, ESPNOW_ENABLE in config.py

import time
import my_oled
import config
import leds

def _log(tag, msg):
    print('[{}] {}'.format(tag, msg))

def _oled_status(title, line1='', line2='', line3=''):
    my_oled.clear()
    my_oled.title_bar(title, invert=True)
    if line1: my_oled.text(line1[:16], 0, 14)
    if line2: my_oled.text(line2[:16], 0, 26)
    if line3: my_oled.text(line3[:16], 0, 38)
    my_oled.show()

def init_espnow():
    if not config.ESPNOW_ENABLE:
        _log('ESPNOW', 'Disabled')
        return None, False
    _log('ESPNOW', 'Initialising...')
    _oled_status('ESP-NOW', 'Starting...')
    try:
        import network
        import espnow
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True)
        time.sleep_ms(300)
        e = espnow.ESPNow()
        try:
            e.active(True)
        except Exception as ex:
            _log('ESPNOW', 'Already active')
        time.sleep_ms(300)
        mac = bytes(config.ADRIAN_MAC)
        try:
            e.add_peer(mac)
        except Exception as ex:
            _log('ESPNOW', 'add_peer: {}'.format(ex))
        mac_str = ':'.join('{:02X}'.format(b) for b in config.ADRIAN_MAC)
        _log('ESPNOW', 'Ready -- {}'.format(mac_str))
        _oled_status('ESP-NOW', 'Ready!', mac_str[:16])
        leds.boot_espnow_ok()
        time.sleep_ms(500)
        return e, True
    except ImportError:
        _log('ESPNOW', 'No module')
        _oled_status('ESP-NOW', 'No module')
        time.sleep_ms(500)
        return None, False
    except Exception as ex:
        _log('ESPNOW', 'FAILED: {}'.format(ex))
        _oled_status('ESP-NOW', 'FAILED', str(ex)[:16])
        time.sleep_ms(500)
        return None, False

def connect_wifi():
    if not config.WIFI_ENABLE:
        _log('WIFI', 'Disabled')
        return None, False
    _log('WIFI', 'Connecting...')
    _oled_status('WiFi', 'Connecting...', config.WIFI_SSID)
    try:
        import network
        wlan = network.WLAN(network.STA_IF)
        if not wlan.active():
            wlan.active(True)
            time.sleep_ms(300)
        if wlan.isconnected():
            ip = wlan.ifconfig()[0]
            _log('WIFI', 'Already up -- {}'.format(ip))
            _oled_status('WiFi', 'Already up', ip)
            leds.boot_wifi_ok()
            time.sleep_ms(500)
            return wlan, True
        wlan.connect(config.WIFI_SSID, config.WIFI_PASSWORD)
        deadline = time.ticks_add(time.ticks_ms(), config.WIFI_TIMEOUT_MS)
        dots = 0
        while not wlan.isconnected():
            if time.ticks_diff(deadline, time.ticks_ms()) <= 0:
                _log('WIFI', 'TIMEOUT')
                _oled_status('WiFi', 'TIMEOUT', 'Use menu retry')
                leds.boot_wifi_fail()
                time.sleep_ms(800)
                return wlan, False
            dots = (dots + 1) % 4
            _oled_status('WiFi', 'Connecting' + '.' * dots, config.WIFI_SSID)
            time.sleep_ms(500)
        ip = wlan.ifconfig()[0]
        _log('WIFI', 'Connected -- {}'.format(ip))
        _oled_status('WiFi', 'Connected!', ip)
        leds.boot_wifi_ok()
        time.sleep_ms(600)
        return wlan, True
    except Exception as ex:
        _log('WIFI', 'FAILED: {}'.format(ex))
        _oled_status('WiFi', 'FAILED', str(ex)[:16])
        leds.boot_wifi_fail()
        time.sleep_ms(800)
        return None, False

def connect_mqtt(wifi_ok):
    if not config.MQTT_ENABLE or not wifi_ok:
        _log('MQTT', 'Disabled or no WiFi')
        return None, False
    _log('MQTT', 'Connecting...')
    _oled_status('MQTT', 'Connecting...')
    try:
        from umqtt.simple import MQTTClient
        cid = 'hmi1_{}'.format(int(time.ticks_ms()) & 0xFFFF)
        c = MQTTClient(cid, config.MQTT_SERVER,
                       user=config.MQTT_USER,
                       password=config.MQTT_PASSWORD,
                       keepalive=60)
        c.connect()
        c.subscribe(config.TOPIC_SUB)
        _log('MQTT', 'Connected!')
        _oled_status('MQTT', 'Connected!')
        time.sleep_ms(500)
        return c, True
    except ImportError:
        _log('MQTT', 'No library')
        time.sleep_ms(500)
        return None, False
    except Exception as ex:
        _log('MQTT', 'FAILED: {}'.format(ex))
        _oled_status('MQTT', 'FAILED', str(ex)[:16])
        time.sleep_ms(800)
        return None, False

def uart_ping(uart):
    from protocol import PREFIX, SUFFIX, MY_ID
    _log('UART', 'Pinging Adrian...')
    _oled_status('UART', 'Pinging sub 2...')
    ping = PREFIX + MY_ID + '2' + 'P' + SUFFIX
    uart.write(ping.encode())
    deadline = time.ticks_add(time.ticks_ms(), 1500)
    buf = ''
    while time.ticks_diff(deadline, time.ticks_ms()) > 0:
        if uart.any():
            raw = uart.read()
            if raw:
                try: buf += raw.decode('utf-8', 'ignore')
                except: pass
                s = buf.find(PREFIX)
                e = buf.find(SUFFIX, s + 2) if s != -1 else -1
                if s != -1 and e != -1:
                    payload = buf[s + 2: e]
                    sender = payload[0] if payload else ''
                    if sender == MY_ID:
                        buf = buf[e + 2:]; continue
                    elif sender == '2':
                        _log('UART', 'Adrian online!')
                        _oled_status('UART', 'Adrian online!')
                        time.sleep_ms(500)
                        return True
                    else:
                        buf = buf[e + 2:]
        time.sleep_ms(50)
    _log('UART', 'No reply')
    _oled_status('UART', 'No reply')
    time.sleep_ms(500)
    return False

def run(uart):
    _log('BOOT', '=== HMI Sub1 Team308 ===')
    _log('BOOT', 'WiFi:{} MQTT:{} ESPNOW:{}'.format(
        config.WIFI_ENABLE, config.MQTT_ENABLE, config.ESPNOW_ENABLE))
    my_oled.splash('HMI  SUB1', 'Team 308', 'EGR314')
    time.sleep_ms(300)
    enow, enow_ok = init_espnow()
    uart_ok       = uart_ping(uart)
    wlan, wifi_ok = connect_wifi()
    mqtt, mqtt_ok = connect_mqtt(wifi_ok)
    if wifi_ok: leds.boot_complete_ok()
    else:       leds.boot_complete_fail()
    def _t(ok): return 'OK' if ok else 'NO'
    _log('BOOT', 'EN:{} UA:{} WF:{} MQ:{}'.format(
        _t(enow_ok), _t(uart_ok), _t(wifi_ok), _t(mqtt_ok)))
    my_oled.clear()
    my_oled.title_bar('Boot Status', invert=True)
    my_oled.text('ESPNOW: ' + ('ON' if config.ESPNOW_ENABLE else 'OFF') + ' ' + _t(enow_ok), 0, 13)
    my_oled.text('UART  : ' + _t(uart_ok),  0, 23)
    my_oled.text('WiFi  : ' + ('ON' if config.WIFI_ENABLE else 'OFF') + ' ' + _t(wifi_ok), 0, 33)
    my_oled.text('MQTT  : ' + ('ON' if config.MQTT_ENABLE else 'OFF') + ' ' + _t(mqtt_ok), 0, 43)
    my_oled.status_bar('BOOT DONE', '')
    my_oled.show()
    time.sleep_ms(1500)
    return {
        'wlan': wlan, 'wifi_ok': wifi_ok,
        'mqtt': mqtt, 'mqtt_ok': mqtt_ok,
        'espnow': enow, 'espnow_ok': enow_ok,
        'uart_ok': uart_ok,
    }
