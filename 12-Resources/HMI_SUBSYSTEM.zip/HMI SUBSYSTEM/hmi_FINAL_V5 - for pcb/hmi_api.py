# hmi_api.py — HMI Subsystem (Subsystem 1) — Full Class Protocol Implementation
#
# Class packet format:
#   AZ + sender_id + receiver_id + message_data + BY
#   0x41 0x5A                                    0x59 0x42
#
# Daisy-chain rules (per assignment):
#   - Packets FOR ME     → process and ACK
#   - Packets for OTHERS → forward downstream immediately, before sending own msgs
#   - Packets FROM ME    → trash (loop-back, ignore)
#   - Unknown sender     → error, trash
#   - Malformed packet   → error, trash
#   - Packet too long    → error, trash
#   - Bytes outside frame → ignore

# ─── Team ID table ────────────────────────────────────────────────────────────
SUBSYS_ME     = 1   # Sam B  — HMI
SUBSYS_ADRIAN = 2   # Adrian P
SUBSYS_ANDREW = 3   # Andrew I
SUBSYS_JACOB  = 4   # Jacob D
SUBSYS_SAMM   = 5   # Sam M
SUBSYS_MO     = 6   # Mo A

KNOWN_SENDERS = {1, 2, 3, 4, 5, 6}

# Class protocol framing bytes
HEADER     = bytes([0x41, 0x5A])   # 'AZ'
FOOTER     = bytes([0x59, 0x42])   # 'BY'
MAX_PACKET = 64                    # max bytes in message_data per spec

# ─── Routing result constants ─────────────────────────────────────────────────
ROUTE_FOR_ME  = 'for_me'
ROUTE_FORWARD = 'forward'
ROUTE_TRASH   = 'trash'
ROUTE_ERROR   = 'error'


# ─── Packet framing ───────────────────────────────────────────────────────────

def frame_packet(sender: int, receiver: int, payload: bytes) -> bytes:
    """
    Build a complete framed packet.
    Clamps payload to MAX_PACKET — cannot send oversized data.
    """
    payload = payload[:MAX_PACKET]
    return HEADER + bytes([sender, receiver]) + payload + FOOTER


def _strip_frame(raw: bytes):
    """
    Validate and strip the AZ/BY frame.
    Returns (sender, receiver, payload) or None on any framing error.
    """
    if len(raw) < 6:
        return None
    if raw[:2] != HEADER:
        return None
    if raw[-2:] != FOOTER:
        return None
    sender   = raw[2]
    receiver = raw[3]
    payload  = raw[4:-2]
    if len(payload) > MAX_PACKET:
        return None   # overflow
    return sender, receiver, payload


# ─── Daisy-chain router ───────────────────────────────────────────────────────

def route_packet(raw: bytes) -> dict:
    """
    Main routing function — call this on every raw UART packet received.

    Returns dict with keys:
      'action'  : ROUTE_FOR_ME | ROUTE_FORWARD | ROUTE_TRASH | ROUTE_ERROR
      'reason'  : human-readable string for serial debug
      'raw'     : original bytes (use this to forward unchanged)
      'sender'  : sender ID if parseable, else None
      'receiver': receiver ID if parseable, else None
      'payload' : payload bytes if parseable, else None
      'msg'     : parsed message dict (only when action == ROUTE_FOR_ME)
    """
    result = {
        'action'  : ROUTE_TRASH,
        'reason'  : '',
        'raw'     : raw,
        'sender'  : None,
        'receiver': None,
        'payload' : None,
        'msg'     : None,
    }

    # ── Error: malformed / oversized frame ───────────────────────────────────
    stripped = _strip_frame(raw)
    if stripped is None:
        result['action'] = ROUTE_ERROR
        result['reason'] = 'ERROR: Malformed packet (bad frame or overflow)'
        return result

    sender, receiver, payload = stripped
    result['sender']   = sender
    result['receiver'] = receiver
    result['payload']  = payload

    # ── Error: unknown sender ─────────────────────────────────────────────────
    if sender not in KNOWN_SENDERS:
        result['action'] = ROUTE_ERROR
        result['reason'] = 'ERROR: Unknown sender ID {}'.format(sender)
        return result

    # ── Trash: loop-back (packet originated from me) ──────────────────────────
    if sender == SUBSYS_ME:
        result['action'] = ROUTE_TRASH
        result['reason'] = 'TRASH: Loop-back from myself (sub {}), ignoring'.format(SUBSYS_ME)
        return result

    # ── Forward: packet is for a teammate ────────────────────────────────────
    if receiver != SUBSYS_ME:
        result['action'] = ROUTE_FORWARD
        result['reason'] = 'FORWARD: receiver={} sender={} — passing downstream'.format(
            receiver, sender)
        return result

    # ── Process: packet is addressed to me ───────────────────────────────────
    msg = _parse_payload(payload)
    result['action'] = ROUTE_FOR_ME
    result['reason'] = 'FOR ME: from sub {} type={}'.format(sender, payload[0] if payload else '?')
    result['msg']    = msg
    return result


# ─── Payload parser ───────────────────────────────────────────────────────────

def _parse_payload(payload: bytes) -> dict:
    """Parse the inner payload of a packet addressed to Subsystem 1."""
    if len(payload) < 1:
        return {'type': None, 'error': 'Empty payload'}

    msg_type = payload[0]

    if msg_type == 1 and len(payload) >= 5:       # Motor speed echo
        return {'type': 1, 'x_speed': payload[1], 'x_dir': payload[2],
                'y_speed': payload[3], 'y_dir': payload[4]}

    if msg_type == 2 and len(payload) >= 4:       # Motor info display
        return {'type': 2, 'motor_id': payload[1],
                'motor_speed': payload[2], 'motor_direction': payload[3]}

    if msg_type == 3 and len(payload) >= 4:       # Sensor value display
        return {'type': 3, 'sensor_number': payload[1],
                'sensor_value': (payload[2] << 8) | payload[3]}

    if msg_type == 12:                            # Status response
        return {'type': 12, 'code': payload[1] if len(payload) >= 2 else 0}

    if msg_type == 10 and len(payload) >= 3:      # Error alert (0x0A)
        return {'type': 14, 'error_code': payload[1], 'sender_num': payload[2]}

    if msg_type == 13 and len(payload) >= 3:      # Status forwarded (0x0D)
        return {'type': 15, 'sender_num': payload[1], 'status_code': payload[2]}

    if msg_type == 0x43 and len(payload) >= 3:   # Button press
        return {'type': 67, 'button_number': payload[1], 'button_state': payload[2]}

    return {'type': msg_type, 'raw_payload': payload}


# ─── ACK builder ─────────────────────────────────────────────────────────────

def build_ack(receiver: int, msg_type: int, extra: bytes = b'') -> bytes:
    """
    Generic ACK — required by assignment for every correctly-received message.
    Format: [0xAA, original_msg_type, ...optional_echo_data]
    0xAA = 170 decimal, used as ACK indicator byte.
    """
    return frame_packet(SUBSYS_ME, receiver, bytes([0xAA, msg_type]) + extra)


# ─── Message builders ─────────────────────────────────────────────────────────

def build_motor_speed(x_speed: int, x_dir: int,
                      y_speed: int, y_dir: int) -> bytes:
    """Type 1 — Joystick 1 motor command to Adrian."""
    x_speed = max(0, min(15, x_speed))
    y_speed = max(0, min(15, y_speed))
    return frame_packet(SUBSYS_ME, SUBSYS_ADRIAN,
                        bytes([1, x_speed, 1 if x_dir else 0,
                                  y_speed, 1 if y_dir else 0, 0x00]))


def build_status_request() -> bytes:
    """Type 12 — Request system status from Adrian."""
    return frame_packet(SUBSYS_ME, SUBSYS_ADRIAN, bytes([12]))


def build_error_ack(error_code: int) -> bytes:
    """Type 14 ACK — Confirm error received and displayed."""
    error_code = max(0, min(64, error_code))
    return frame_packet(SUBSYS_ME, SUBSYS_ADRIAN, bytes([10, error_code]))


def build_button_press(button_number: int, button_state: int) -> bytes:
    """Type 67 — Joystick click-in button event."""
    button_number = max(1, min(2, button_number))
    return frame_packet(SUBSYS_ME, SUBSYS_ADRIAN,
                        bytes([0x43, button_number, 1 if button_state else 0]))


def build_demo_packet() -> bytes:
    """
    Time-varying demo packet for checkoff — x_speed cycles 0→15.
    Call repeatedly to show changing data on the wire.
    """
    import utime
    x_spd = int((utime.ticks_ms() % 1000) / 1000 * 15)
    return build_motor_speed(x_spd, 0, 0, 0)


# ─── Joystick ADC helper ──────────────────────────────────────────────────────

def adc_to_speed_dir(adc_val: int, center: int = 2048,
                     dead_zone: int = 200) -> tuple:
    """Convert 12-bit ADC to (speed 0–15, direction 0/1)."""
    delta = adc_val - center
    if abs(delta) <= dead_zone:
        return 0, 0
    if delta > 0:
        speed = int((delta - dead_zone) / ((4095 - center - dead_zone) / 15))
        return max(0, min(15, speed)), 1
    speed = int((-delta - dead_zone) / ((center - dead_zone) / 15))
    return max(0, min(15, speed)), 0