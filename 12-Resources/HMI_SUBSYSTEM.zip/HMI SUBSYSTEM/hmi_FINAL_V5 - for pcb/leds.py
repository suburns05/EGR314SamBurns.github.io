
from machine import Pin
import time
import config

_led1 = Pin(config.LED_WIFI_PIN, Pin.OUT)   # GPIO 21
_led2 = Pin(config.LED_BLUE_PIN, Pin.OUT)   # GPIO 23

def _on(led):  led.value(1)
def _off(led): led.value(0)

_led2_alert_until = 0    # ticks_ms deadline for LED2 timed events
_led2_error_mode  = False # True = rapid blink until cleared
_led1_wifi_on     = False # True = WiFi connected, LED1 stays on at idle

def _blink(led, n, on_ms=120, off_ms=120):
    
    for i in range(n):
        _on(led)
        time.sleep_ms(on_ms)
        _off(led)
        if i < n - 1:
            time.sleep_ms(off_ms)

def _both_blink(n=1, on_ms=120, off_ms=120):
    for i in range(n):
        _on(_led1); _on(_led2)
        time.sleep_ms(on_ms)
        _off(_led1); _off(_led2)
        if i < n - 1:
            time.sleep_ms(off_ms)

def boot_wifi_ok():
    
    global _led1_wifi_on
    _blink(_led1, 3, on_ms=150, off_ms=100)
    time.sleep_ms(200)
    _on(_led1)
    _led1_wifi_on = True
    print('[LED] WiFi OK -- LED1 on')

def boot_wifi_fail():
    
    global _led1_wifi_on
    _led1_wifi_on = False
    _off(_led1)
    _on(_led2)
    print('[LED] WiFi FAIL -- LED2 solid warning')

def boot_espnow_ok():
    
    _both_blink(1, on_ms=200)
    if _led1_wifi_on:
        _on(_led1)
    print('[LED] ESP-NOW OK -- both blinked')

def boot_complete_ok():
    
    _off(_led2)

def boot_complete_fail():
    
    _on(_led2)

def evt_tx(msg_type_int):
    
    if msg_type_int == 1:
        return
    _blink(_led1, 1, on_ms=40, off_ms=0)
    if _led1_wifi_on:
        _on(_led1)   # restore steady state

def evt_rx_important(msg_type_int):
    
    _blink(_led1, 2, on_ms=40, off_ms=40)
    if _led1_wifi_on:
        _on(_led1)

def evt_rx_forward():
    
    _blink(_led1, 1, on_ms=200, off_ms=0)
    if _led1_wifi_on:
        _on(_led1)

def evt_bad_packet():
    
    global _led2_alert_until
    _on(_led2)
    _led2_alert_until = time.ticks_add(time.ticks_ms(), 500)
    print('[LED] Bad packet -- LED2 500ms')

def evt_error_alert(active=True):
    
    global _led2_error_mode
    _led2_error_mode = active
    if not active:
        _off(_led2)
    print('[LED] Error mode: {}'.format(active))

def evt_status_rx():
    
    global _led2_alert_until
    _blink(_led2, 1, on_ms=80, off_ms=0)
    _off(_led2)

def evt_wifi_lost():
    
    global _led2_error_mode
    _led2_error_mode = True
    print('[LED] WiFi lost -- LED2 pulsing')

def evt_wifi_restored():
    global _led2_error_mode, _led1_wifi_on
    _led2_error_mode = False
    _led1_wifi_on    = True
    _on(_led1)
    _off(_led2)
    print('[LED] WiFi restored')

def evt_network_retry_ok():
    
    _both_blink(3, on_ms=100, off_ms=80)
    _on(_led1)
    _off(_led2)

def evt_network_retry_fail():
    
    _on(_led2)

_poll_tick = 0
_led2_pulse_state = 0
_led2_pulse_last  = 0

def poll():
    
    global _led2_alert_until, _led2_pulse_state, _led2_pulse_last

    now = time.ticks_ms()

    if _led2_alert_until and time.ticks_diff(now, _led2_alert_until) >= 0:
        _off(_led2)
        _led2_alert_until = 0

    if _led2_error_mode:
        if time.ticks_diff(now, _led2_pulse_last) >= 250:
            _led2_pulse_state = 1 - _led2_pulse_state
            _led2.value(_led2_pulse_state)
            _led2_pulse_last = now
