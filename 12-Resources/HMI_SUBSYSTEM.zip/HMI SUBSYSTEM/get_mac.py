# get_mac.py -- Run this once to get your ESP32 MAC addresses
# Flash as main.py, read terminal, send MACs to Adrian, then restore main.py

import network
import ubinascii
import time

# WiFi MAC
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wifi_mac = ubinascii.hexlify(wlan.config('mac'), ':').decode().upper()

# AP MAC (sometimes different)
ap = network.WLAN(network.AP_IF)
ap.active(True)
ap_mac = ubinascii.hexlify(ap.config('mac'), ':').decode().upper()

# Format for config.py
def mac_to_list(mac_str):
    return '[' + ', '.join('0x'+b for b in mac_str.split(':')) + ']'

print('=' * 40)
print('HMI Subsystem 1 -- MAC Addresses')
print('=' * 40)
print('WiFi STA MAC : {}'.format(wifi_mac))
print('WiFi AP  MAC : {}'.format(ap_mac))
print()
print('For Adrian config.py (use STA MAC):')
print('HMI_MAC = {}'.format(mac_to_list(wifi_mac)))
print()
print('For ESP-NOW -- Adrian adds this as peer:')
print('e.add_peer(bytes({}))'.format(mac_to_list(wifi_mac)))
print('=' * 40)
print('Send the STA MAC line to Adrian.')
print('Restore main.py when done.')

# Keep printing so you can read it
while True:
    time.sleep_ms(3000)
    print('WiFi STA: {}  |  AP: {}'.format(wifi_mac, ap_mac))
 